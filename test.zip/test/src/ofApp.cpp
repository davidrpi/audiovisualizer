#include "ofApp.h"

const int N = 256;		//BANDS IN SPECTRUM
float spectrum[ N ];	//SMOOTHED SPECTRUM VALUES
float Rad = 500;		//RADIUS PARM
float Vel = 0.1;		//POINTS VELOCITY
int bandRad = 2;		//BAND INDEX FOR RAD
int bandVel = 100;		//BAND INDEX FOR VELOCITY

const int n = 300;		//NUM OF PARTICLES

float tx[n], ty[n];     //OFFSETS FOR PERLIN NOISE CALC
ofPoint p[n];			//POINT POSITIONS

float time0 = 0;		//TIME

bool one = false;       //WHEN TRUE, CIRCLES ARE DRAWN
bool two = false;       //WHEN TRUE, RECTANGLES ARE DRAWN
bool three = false;     //WHEN TRUE, TRIANGLES ARE DRAWN
bool full = false;      //WHEN TRUE, FULLSCREEN IS ENABLED

//--------------------------------------------------------------
void ofApp::setup(){
    sound.loadSound( "mytype.mp3" ); //BY SAINT MOTEL
    sound.setLoop( true );
    sound.play();
    
    ofSetRectMode(OF_RECTMODE_CENTER);
    
    // initialise member variables to the centre of the screen
    mouseXPercent = 0.5f;
    mouseYPercent = 0.5f;
    
    for (int i=0; i<N; i++) { //SET SPECTRUM VALS TO 0
        spectrum[i] = 0.0f;
    }
    
    for ( int j=0; j<n; j++ ) { //SET OFFSETS RANDOMLY
        tx[j] = ofRandom( 0, 1000 );
        ty[j] = ofRandom( 0, 1000 );
    }
}

//--------------------------------------------------------------
void ofApp::update(){
    ofSoundUpdate(); //UPDATE SOUND ENGINE
    float *val = ofSoundGetSpectrum( N ); //CURRENT SPECTRUM

    for ( int i=0; i<N; i++ ) { //SLOWLY DECREASING SPECTRUM
        spectrum[i] *= 0.97;
        spectrum[i] = max( spectrum[i], val[i] );
    }
    
    float time = ofGetElapsedTimef();
    float dt = time - time0;
    dt = ofClamp( dt, 0.0, 0.1 ); //DIFFERENCE IN TIME
    time0 = time; //UPDATE TIME
    
    Rad = ofMap( spectrum[ bandRad ], 1, 3, 400, 800, true ); //UPDATE RAD
    Vel = ofMap( spectrum[ bandVel ], 0, 0.1, 0.05, 0.5 ); //UPDATE VELOCITY
    
    //Update particles positions
    for (int j=0; j<n; j++) { //PARTICAL POSITIONS
        tx[j] += Vel * dt;
        ty[j] += Vel * dt;
        p[j].x = ofSignedNoise( tx[j] ) * Rad; // ofSignedNoise() = PERLIN'S NOISE
        p[j].y = ofSignedNoise( ty[j] ) * Rad; // RETURNS BETWEEN RANGE OF [-1, 1]
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetFullscreen(full);
    ofBackground( 255, 255, 255 );
    
    float hue = fmodf(ofGetElapsedTimef()*10,255);
    ofColor color = ofColor::fromHsb(hue, ofMap( mouseX, 0,ofGetWidth(), 0,255 ), ofMap( mouseY, ofGetHeight(),0, 0,255 ) );
    ofSetColor( color );
    ofFill();
    ofRect( mouseX, mouseY, 2500*2, 2500*2); //SET BACKGROUND COLOR
    
    ofPushMatrix();
    ofTranslate( ofGetWidth() / 2, ofGetHeight() / 2 ); //CENTER MATRIX
    

    for (int i=0; i<n; i++) { //DRAW PARTICLES
        determineColor();
        ofCircle( p[i], 2 );
    }
    
    float dist = 65;	//MAX DISTANCE BETWEEN PARTICLES
    for (int d=0; d<n; d++) {
        for (int k=d+1; k<n; k++) {
            if (ofDist( p[d].x, p[d].y, p[k].x, p[k].y ) < dist ) { //DRAWS SPECIFIED SHAPE: CIRCLE, RECTANGLE, OR TRIANGLE
                determineColor();
                if(one) ofCircle((p[d].x+p[k].x)/2, (p[d].y+p[k].y)/2, ofMap( mouseY, ofGetHeight(),0, 0,35 ));
                if(two) ofRect((p[d].x+p[k].x)/2, (p[d].y+p[k].y)/2, ofMap( mouseX, ofGetWidth(),0, 0,35 ), ofMap( mouseY, ofGetHeight(),0, 0,35 ));
                if(three) ofTriangle(p[d].x, p[d].y, p[k].x, p[k].y, ofMap( mouseX, ofGetWidth(),0, 0,35 ), ofMap( mouseY, ofGetHeight(),0, 0,35 ));
            }
        }
    }
    ofPopMatrix(); //RESTORE COORDINATE SYSTEM
}

void ofApp::determineColor(){ //INVERTS PARTICLES AND SHAPES DEPENDING ON BRIGHTNESS AND HUE
    if(ofMap( mouseY, ofGetHeight(),0, 0,255 ) > 80){
        ofSetColor(0,0,0); //BLACK
    }
    else{
        ofSetColor(255,255,255); //WHITE
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    //SET SHAPE
    if(key == '1'){ //1 = CIRCLES
        one = true;
        two = false;
        three = false;
    }
    if(key == '2'){ //2 = RECTANGLES
        one = false;
        two = true;
        three = false;
    }
    if(key == '3'){ //3 = TRIANGLES
        one = false;
        two = false;
        three = true;
    }
    if(key == '0'){ //0 = RESET PARTICLES
        one = false;
        two = false;
        three = false;
    }
    if(key == 'f'){ //F = ENABLES/DISABLES FULLSCREEN
        if(full){
            full = false;
        }
        else{
            full = true;
        }
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
    ofHideCursor();
    //UPDATE WHEN MOUSE MOVES ON BOTH X AND Y AXIS
    mouseXPercent = float(x) / ofGetWidth();
    mouseYPercent = float(y) / ofGetHeight();
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 
    
}